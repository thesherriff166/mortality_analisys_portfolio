"""Mortality and survival calculations from a cleaned qx table."""
import numpy as np
import pandas as pd


def load_qx(path="data/qx_clean.csv", geo="Canada", sex="Males", period="2022/2024"):
    """Return qx as a Series indexed by age (0..110) for one geo/sex/period."""
    df = pd.read_csv(path)
    sub = df[(df.geo == geo) & (df.sex == sex) & (df.period == period)]
    if sub.empty:
        raise ValueError(f"No rows for {geo}, {sex}, {period}")
    return sub.set_index("age")["qx"].sort_index()


def survival_probs(qx, issue_age, n):
    """Return array [0px, 1px, ..., npx] for a life aged issue_age.

    tpx = product over k=0..t-1 of (1 - q_{x+k}).
    """
    last_age = issue_age + n - 1
    if issue_age not in qx.index or last_age not in qx.index:
        raise ValueError(f"Need qx for ages {issue_age}..{last_age}")
    q = qx.loc[issue_age:last_age].to_numpy()
    return np.concatenate(([1.0], np.cumprod(1.0 - q)))
