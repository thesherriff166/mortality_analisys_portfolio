"""EPV and net premium calculations for an n-year term policy
(end-of-year death benefit, level premiums payable at start of each year)."""
import numpy as np
from survival_model import survival_probs


def epv_death_benefit(qx, issue_age, n, i, benefit=1.0):
    """EPV = sum_{t=1..n} B v^t (t-1)px q_{x+t-1}. Equals the net single premium."""
    tpx = survival_probs(qx, issue_age, n)          # tpx[t] for t=0..n
    q = qx.loc[issue_age:issue_age + n - 1].to_numpy()  # q_{x+t-1}, t=1..n
    t = np.arange(1, n + 1)
    return float(np.sum(benefit * (1 + i) ** (-t) * tpx[:n] * q))


def temp_annuity_due(qx, issue_age, n, i):
    """a-double-dot_{x:n} = sum_{t=0..n-1} v^t tpx."""
    tpx = survival_probs(qx, issue_age, n)
    t = np.arange(0, n)
    return float(np.sum((1 + i) ** (-t) * tpx[:n]))


def net_single_premium(qx, issue_age, n, i, benefit=250_000):
    return epv_death_benefit(qx, issue_age, n, i, benefit)


def level_annual_net_premium(qx, issue_age, n, i, benefit=250_000):
    return epv_death_benefit(qx, issue_age, n, i, benefit) / temp_annuity_due(qx, issue_age, n, i)
