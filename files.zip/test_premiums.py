import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from survival_model import survival_probs
from premium_calculator import (epv_death_benefit, temp_annuity_due,
                                net_single_premium, level_annual_net_premium)

AGES = range(0, 111)


def make_qx(f):
    return pd.Series([f(a) for a in AGES], index=pd.Index(AGES, name="age"))


QX = make_qx(lambda a: min(1.0, 0.0005 * 1.09 ** a))   # hypothetical, test only


def test_survival_starts_at_one_and_non_increasing():
    s = survival_probs(QX, 35, 20)
    assert s[0] == 1.0
    assert np.all(np.diff(s) <= 0)
    assert np.all((s >= 0) & (s <= 1))


def test_zero_mortality_gives_zero_epv():
    zero = make_qx(lambda a: 0.0)
    assert epv_death_benefit(zero, 40, 10, 0.03, 250_000) == 0.0


def test_benefit_scales_premiums_proportionally():
    a = level_annual_net_premium(QX, 40, 10, 0.03, 100_000)
    b = level_annual_net_premium(QX, 40, 10, 0.03, 500_000)
    assert b == pytest.approx(5 * a)


def test_certain_death_year_one():
    q1 = make_qx(lambda a: 1.0)
    assert epv_death_benefit(q1, 30, 5, 0.03, 1.0) == pytest.approx(1 / 1.03)


def test_term_identity():
    # A^1_{x:n} + v^n npx = 1 - d * a-due_{x:n}
    x, n, i = 45, 15, 0.04
    v = 1 / (1 + i)
    d = i / (1 + i)
    lhs = epv_death_benefit(QX, x, n, i, 1.0) + v ** n * survival_probs(QX, x, n)[n]
    rhs = 1 - d * temp_annuity_due(QX, x, n, i)
    assert lhs == pytest.approx(rhs)


def test_level_premium_equivalence():
    x, n, i, B = 35, 10, 0.03, 250_000
    P = level_annual_net_premium(QX, x, n, i, B)
    assert P * temp_annuity_due(QX, x, n, i) == pytest.approx(net_single_premium(QX, x, n, i, B))


def test_higher_interest_lowers_premium():
    assert level_annual_net_premium(QX, 40, 20, 0.07) < level_annual_net_premium(QX, 40, 20, 0.01)
